edit uc_update_data_zone.module

1) Update Zones You need - edit uc_update_data_zone.module - pay attention to ZID.
db_query("INSERT INTO {uc_shipping_zones} (zid, name, countries, regions) VALUES ('1','Puglia','Italy,380','Bari,88|Barletta-Andria-Trani,96|Brindisi,94|Foggia,113|Lecce,124|Taranto,171')");
db_query("INSERT INTO {uc_shipping_zones} (zid, name, countries, regions) VALUES ('2','Calabria','Italy,380','Catanzaro,109|Cosenza,107|Crotone,122|Reggio Calabria,157|Vibo Valentia,188')");
db_query("INSERT INTO {uc_shipping_zones} (zid, name, countries, regions) VALUES ('3','Sardegna','Italy,380','Cagliari,98|Carbonia-Iglesias,102|Medio Campidano,186|Nuoro,139|Ogliastra,140|Olbia-Tempio,142|Oristano,141|Sassari,169')");
db_query("INSERT INTO {uc_shipping_zones} (zid, name, countries, regions) VALUES ('8','Piemonte','Italy,380','Alessandria,80|Asti,86|Biella,90|Cuneo,104|Novara,138|Torino,174|Verbano-Cusio-Ossola,181|Vercelli,182')");

2)
Update quote you need - edit uc_update_data_zone.module - pay attention to ZID.
example for region 8 piemonte
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('63','8','0.01000','9.99000','10.00000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('64','8','10.00000','19.99000','13.00000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('65','8','20.00000','39.99000','16.00000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('66','8','40.00000','59.99000','20.00000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('67','8','60.00000','79.99000','25.00000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('68','8','80.00000','99.99000','27.00000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('69','8','100.00000','149.99000','31.60000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('70','8','150.00000','199.99000','44.40000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('71','8','200.00000','249.99000','57.20000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('72','8','250.00000','299.99000','70.00000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('73','8','300.00000','349.99000','82.80000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('74','8','350.00000','399.99000','96.60000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('75','8','400.00000','449.99000','109.40000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('76','8','450.00000','499.99000','123.20000')");
db_query("INSERT INTO {uc_global_quote} (qid, zid, min, max, rate) VALUES ('77','8','500.00000','600.00000','136.00000')");


3)
Install "Update data UC zone 7.x-1.0" module and go to admin/store/settings/update-data-zone (store/Update UC zone). than populate.

4)
attention to the words with accented characters (example Forl�) or apostrophes (example L'aquila).
replace with normal characters or without any accent; manually change in admin/store/settings/quotes/methods/zones the correct word.
